// file      : xsde/cxx/hybrid/any-type-simpl.cxx
// author    : Boris Kolpackov <boris@codesynthesis.com>
// copyright : Copyright (c) 2005-2011 Code Synthesis Tools CC
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#include <xsde/cxx/hybrid/any-type-simpl.hxx>

namespace xsde
{
  namespace cxx
  {
    namespace hybrid
    {
      void any_type_simpl::
      pre (const any_type&)
      {
      }
    }
  }
}
