/* file      : xsde/c/compilers/ghs/post.h
 * author    : Boris Kolpackov <boris@codesynthesis.com>
 * copyright : Copyright (c) 2005-2011 Code Synthesis Tools CC
 * license   : GNU GPL v2 + exceptions; see accompanying LICENSE file
 */

#ifdef __EDG__
#  pragma ghs endnowarning
#endif
